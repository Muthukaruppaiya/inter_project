package com.example.quizapp.service;

import com.example.quizapp.model.Topic;
import java.util.List;

public interface TopicService {
    Topic saveTopic(Topic topic);
    List<Topic> findAllTopics();
}
