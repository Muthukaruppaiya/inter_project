package com.example.quizapp.service;

import com.example.quizapp.model.UserAnswer;
import com.example.quizapp.repository.UserAnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserAnswerService {

    @Autowired
    private UserAnswerRepository userAnswerRepository;

    public List<UserAnswer> getAllUserAnswers() {
        return userAnswerRepository.findAll();
    }

    public Optional<UserAnswer> getUserAnswerById(Long id) {
        return userAnswerRepository.findById(id);
    }

    public UserAnswer saveUserAnswer(UserAnswer userAnswer) {
        return userAnswerRepository.save(userAnswer);
    }

    public void deleteUserAnswer(Long id) {
        userAnswerRepository.deleteById(id);
    }
}
